//
//  ApiManger.h
//  ApiManger
//
//  Created by Amey Dalvi on 22/04/24.
//

#import <Foundation/Foundation.h>

//! Project version number for ApiManger.
FOUNDATION_EXPORT double ApiMangerVersionNumber;

//! Project version string for ApiManger.
FOUNDATION_EXPORT const unsigned char ApiMangerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ApiManger/PublicHeader.h>


